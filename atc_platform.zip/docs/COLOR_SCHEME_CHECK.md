# Проверка цветовой схемы

## Определенные цвета в проекте

### Основные цвета (из main.css)

1. **Primary (Синий)** - `bg-primary`

   - Переменная: `--color-primary` → `var(--color-brand-500)` → `#465fff`
   - Используется для: основных действий, редактирование, навигация

2. **Success (Зеленый)** - `bg-success`

   - Переменная: `--color-success` → `var(--color-success-600)` → `#039855`
   - Используется для: создание, сохранение, подтверждение

3. **Danger (Красный)** - `bg-danger`

   - Переменная: `--color-danger` → `var(--color-error-600)` → `#d92d20`
   - Используется для: удаление, отмена, критические действия

4. **Warning (Желтый)** - `bg-warning`

   - Переменная: `--color-warning` → `var(--color-warning-600)` → `#dc6803`
   - Используется для: предупреждения, важные изменения

5. **Secondary/Stroke (Серый)** - `bg-stroke`, `border-stroke`
   - Переменная: `--color-stroke` → `var(--color-gray-200)` → `#e4e7ec`
   - Используется для: второстепенные элементы, границы

## Где используются цвета

### Компоненты пользователей

1. **UserManagementPanel.vue** (строка 13-16)

   ```vue
   <BaseButton variant="success" size="md" @click="openCreateModal">
     Добавить пользователя
   </BaseButton>
   ```

   ✅ Зеленая кнопка для создания

2. **UserFormModal.vue** (строки 188-203)

   ```vue
   <BaseButton variant="secondary" outline @click="$emit('close')">
     Отмена
   </BaseButton>
   <BaseButton variant="success" type="submit" :loading="loading">
     Сохранить
   </BaseButton>
   ```

   ✅ Серая кнопка отмены (outline)
   ✅ Зеленая кнопка сохранения

3. **UserTable.vue** (строки 97-145)
   ```vue
   <BaseButton variant="primary" size="sm">
     Изменить
   </BaseButton>
   <BaseButton variant="danger" size="sm">
     Удалить
   </BaseButton>
   ```
   ✅ Синяя кнопка редактирования
   ✅ Красная кнопка удаления

### Страница входа

**auth/signin.vue** (строка 124)

```vue
<button class="... bg-primary ...">
  Войти в систему
</button>
```

✅ Синяя кнопка входа

## Предупреждения IDE

Все предупреждения "Unknown at rule" в `main.css` - это **нормально**:

- `@theme`, `@utility`, `@custom-variant`, `@apply` - это директивы Tailwind CSS v4
- IDE не знает о них, но PostCSS корректно их обрабатывает
- Приложение работает правильно

## Как проверить визуально

1. Запустите `npm run dev`
2. Откройте `http://localhost:3000/ui-elements/buttons` - демо всех кнопок
3. Откройте `http://localhost:3000/users` - страница с цветными кнопками управления пользователями
4. Проверьте цвета:
   - 🟢 Зеленые кнопки - "Добавить", "Создать", "Сохранить"
   - 🔴 Красные кнопки - "Удалить"
   - 🔵 Синие кнопки - "Изменить", "Войти"
   - ⚪ Серые кнопки - "Отмена", "Закрыть"

## Итог

✅ Все цвета правильно определены в CSS
✅ Компоненты используют правильные семантические цвета
✅ BaseButton корректно применяет цветовые варианты
✅ Предупреждения IDE можно игнорировать - это особенность Tailwind CSS v4
