# Система допуска для выставления отметок посещаемости инструкторами

## Оглавление

1. [Обзор системы](#обзор-системы)
2. [Правила своевременной отметки](#правила-своевременной-отметки)
3. [Временные окна допуска](#временные-окна-допуска)
4. [Сценарии для инструкторов](#сценарии-для-инструкторов)
5. [Статусы отметки посещаемости](#статусы-отметки-посещаемости)
6. [Уведомления и напоминания](#уведомления-и-напоминания)
7. [Техническая реализация](#техническая-реализация)
8. [API эндпоинты](#api-эндпоинты)
9. [База данных](#база-данных)
10. [UI компоненты](#ui-компоненты)

---

## Обзор системы

### Цель

Обеспечить **своевременную и точную** фиксацию посещаемости студентов инструкторами, с контролем сроков и возможностью эскалации при нарушениях.

### Ключевые принципы

1. **Своевременность** — отметка должна быть сделана в определённые сроки
2. **Ответственность** — каждая отметка привязана к инструктору
3. **Контроль** — администраторы видят, кто опаздывает с отметками
4. **Гибкость** — возможность продления сроков в исключительных случаях

---

## Правила своевременной отметки

### Основные правила

| #   | Правило                           | Описание                                                                                                         |
| --- | --------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| 1   | **Только назначенный инструктор** | Отмечать посещаемость может только тот инструктор, который назначен на занятие (`schedule_events.instructor_id`) |
| 2   | **Только после начала занятия**   | Нельзя отметить посещаемость до начала занятия                                                                   |
| 3   | **Крайний срок**                  | Отметка должна быть сделана до `N` часов после окончания занятия (настраиваемо)                                  |
| 4   | **Редактирование**                | После истечения срока редактирование только с разрешения администратора                                          |
| 5   | **Аудит**                         | Все изменения логируются с указанием времени и автора                                                            |

### Рекомендуемые настройки сроков

| Параметр                                     | Значение по умолчанию | Описание                                  |
| -------------------------------------------- | --------------------- | ----------------------------------------- |
| `ATTENDANCE_MARK_DEADLINE_HOURS`             | 24                    | Часов после занятия для обычной отметки   |
| `ATTENDANCE_EDIT_DEADLINE_HOURS`             | 72                    | Часов после занятия для редактирования    |
| `ATTENDANCE_LATE_MARK_ALLOWED`               | true                  | Разрешить опоздавшую отметку (с пометкой) |
| `ATTENDANCE_REQUIRE_APPROVAL_AFTER_DEADLINE` | true                  | Требовать одобрение после дедлайна        |

---

## Временные окна допуска

### Диаграмма временных зон

```
                  ЗАНЯТИЕ
    ◄──────────────│═══════════════│──────────────────────────────────►
                   │               │
              START_TIME       END_TIME
                   │               │
    ════════════════════════════════════════════════════════════════════

    ЗОНА 1         │    ЗОНА 2     │    ЗОНА 3     │    ЗОНА 4    │ ЗОНА 5
    (До занятия)   │ (Во время)    │ (Оптимально)  │ (Допустимо)  │ (Просрочено)
    ───────────────┼───────────────┼───────────────┼──────────────┼─────────────
    ❌ Отметка     │ ✅ Рекомендуется│ ✅ Норма      │ ⚠️ Опоздание │ 🔒 Требует
       запрещена   │    в конце    │               │ (с пометкой) │    одобрения
                   │    занятия    │               │              │
                   │               │◄──── 24ч ────►│◄── 48ч ────►│
```

### Зоны допуска

| Зона  | Название           | Период                        | Права инструктора         | Статус отметки         |
| ----- | ------------------ | ----------------------------- | ------------------------- | ---------------------- |
| **1** | До занятия         | До `start_time`               | ❌ Запрещено              | —                      |
| **2** | Во время занятия   | `start_time` → `end_time`     | ✅ Разрешено              | `in_progress`          |
| **3** | Оптимальный период | `end_time` → `end_time + 24ч` | ✅ Разрешено              | `on_time`              |
| **4** | Период опоздания   | `+24ч` → `+72ч`               | ✅ Разрешено (с пометкой) | `late`                 |
| **5** | Просрочено         | После `+72ч`                  | ⚠️ Требует одобрения      | `overdue` → `approved` |

---

## Сценарии для инструкторов

### Сценарий 1: Стандартная отметка (в срок)

```
📋 СЦЕНАРИЙ: Обычное занятие

1. Инструктор проводит занятие (09:00 - 12:00)
2. После занятия заходит в журнал группы
3. Отмечает присутствующих/отсутствующих
4. Система фиксирует: marked_at = текущее время, status = 'on_time'
5. ✅ Готово
```

**Действия системы:**

- Сохранить данные посещаемости
- Записать в лог действие `ATTENDANCE_MARK`
- Обновить статистику группы

---

### Сценарий 2: Отметка с опозданием (24-72ч)

```
📋 СЦЕНАРИЙ: Инструктор забыл отметить вовремя

1. Прошло 30 часов после занятия
2. Инструктор заходит в журнал
3. Система показывает предупреждение:
   ⚠️ "Срок отметки истёк. Отметка будет помечена как 'Опоздание'"
4. Инструктор подтверждает действие
5. Указывает причину опоздания (опционально)
6. Система фиксирует: status = 'late', late_reason = '...'
```

**Действия системы:**

- Показать предупреждение
- Потребовать подтверждение
- Сохранить с меткой `late`
- Уведомить администратора (опционально)
- Записать в лог с пометкой `ATTENDANCE_MARK_LATE`

---

### Сценарий 3: Просроченная отметка (после 72ч)

```
📋 СЦЕНАРИЙ: Критическое опоздание

1. Прошло 5 дней после занятия
2. Инструктор заходит в журнал
3. Система показывает:
   🔒 "Срок отметки истёк. Требуется одобрение администратора"
4. Варианты:
   A) Инструктор создаёт запрос на разрешение
   B) Администратор может разблокировать вручную
```

**Действия системы:**

- Блокировать прямое редактирование
- Предложить создать запрос
- Уведомить администратора
- После одобрения — разрешить отметку с меткой `approved`

---

### Сценарий 4: Редактирование существующей отметки

```
📋 СЦЕНАРИЙ: Исправление ошибки

1. Инструктор уже отметил студента как "присутствует"
2. Понял, что ошибся — студент опоздал
3. Редактирует запись:
   - Если в пределах 72ч: ✅ разрешено
   - Если после 72ч: 🔒 требует одобрения
4. Система сохраняет историю изменений
```

**Действия системы:**

- Проверить временное окно
- Сохранить предыдущее значение в историю
- Обновить запись
- Записать в лог `ATTENDANCE_EDIT`

---

### Сценарий 5: Замена инструктора

```
📋 СЦЕНАРИЙ: Другой инструктор провёл занятие

1. Инструктор А назначен на занятие
2. Инструктор Б замещает его
3. Варианты:
   A) Администратор меняет instructor_id в событии
   B) Инструктор А делегирует права инструктору Б (новая фича)
   C) Администратор отмечает посещаемость вручную
```

**Рекомендуемое решение:**

- Администратор меняет `instructor_id` до или после занятия
- Новый инструктор получает права на отметку

---

### Сценарий 6: Групповое занятие с несколькими инструкторами

```
📋 СЦЕНАРИЙ: Два преподавателя ведут занятие

1. На занятии два инструктора (основной + ассистент)
2. В системе указан только один instructor_id
3. Варианты:
   A) Отмечает только назначенный инструктор
   B) Добавить поле co_instructor_id
   C) Любой инструктор группы может отмечать
```

**Рекомендация:**

- Основной инструктор отвечает за отметку
- При необходимости добавить роль "Ассистент" с правами отметки

---

### Сценарий 7: Отмена/перенос занятия

```
📋 СЦЕНАРИЙ: Занятие не состоялось

1. Занятие было в расписании, но отменено
2. Инструктор должен:
   A) Отметить всех как "0 часов" (занятие не было)
   B) Администратор удаляет событие
   C) Событие помечается как "cancelled"
```

**Рекомендация:**

- Добавить статус события `cancelled`
- При отмене — автоматически закрыть посещаемость с 0 часов
- Не требовать обязательной отметки для отменённых занятий

---

### Сценарий 8: Частичное посещение

```
📋 СЦЕНАРИЙ: Студент был на части занятия

1. Занятие 4 академических часа
2. Студент был только 2 часа (ушёл раньше или опоздал)
3. Инструктор отмечает: hours_attended = 2, max_hours = 4
4. Можно добавить примечание: "Ушёл на медосмотр"
```

**Текущая реализация поддерживает этот сценарий** ✅

---

### Сценарий 9: Массовая отметка

```
📋 СЦЕНАРИЙ: Быстрая отметка всей группы

1. Инструктор открывает журнал занятия
2. Видит список всех студентов группы
3. Быстрые действия:
   - "Отметить всех присутствующими"
   - "Отметить всех отсутствующими"
   - Индивидуальная отметка для каждого
4. Сохранение одной кнопкой
```

**Текущая реализация через bulk API** ✅

---

### Сценарий 10: Инструктор без доступа к системе

```
📋 СЦЕНАРИЙ: Инструктор не имеет учётной записи

1. Внешний инструктор проводит занятие
2. Нет логина в системе
3. Варианты:
   A) Создать учётную запись (рекомендуется)
   B) Куратор/администратор отмечает за него
   C) Инструктор присылает данные (email/мессенджер), куратор вносит
```

**Рекомендация:**

- Для постоянных инструкторов — создать учётные записи
- Для разовых — куратор отмечает с указанием "по данным инструктора N"

---

## Статусы отметки посещаемости

### Статусы записи `attendance_marking`

| Статус       | Код           | Описание                                      | Цвет          |
| ------------ | ------------- | --------------------------------------------- | ------------- |
| Не отмечено  | `pending`     | Занятие прошло, отметка не сделана            | 🔘 Серый      |
| В процессе   | `in_progress` | Занятие идёт, частичная отметка               | 🔵 Синий      |
| Вовремя      | `on_time`     | Отмечено в срок                               | 🟢 Зелёный    |
| С опозданием | `late`        | Отмечено после дедлайна (24-72ч)              | 🟡 Жёлтый     |
| Просрочено   | `overdue`     | Не отмечено более 72ч                         | 🔴 Красный    |
| Одобрено     | `approved`    | Просроченная отметка одобрена администратором | 🟣 Фиолетовый |

### Статусы студента на занятии

Текущая система использует `hours_attended` vs `max_hours`:

| Статус                  | Расчёт                           | Описание                |
| ----------------------- | -------------------------------- | ----------------------- |
| Присутствовал полностью | `hours_attended == max_hours`    | Был всё занятие         |
| Частичное присутствие   | `0 < hours_attended < max_hours` | Был часть занятия       |
| Отсутствовал            | `hours_attended == 0`            | Не был                  |
| Уважительная причина    | `hours_attended == 0 + notes`    | Не был по уваж. причине |

---

## Уведомления и напоминания

### Уведомления для инструкторов

| Событие                 | Канал           | Время         | Сообщение                                              |
| ----------------------- | --------------- | ------------- | ------------------------------------------------------ |
| Занятие завершилось     | 🔔 Push / Web   | Сразу         | "Не забудьте отметить посещаемость по занятию [...]"   |
| Осталось 2ч до дедлайна | 🔔 Push / Web   | За 2ч         | "⚠️ Срок отметки посещаемости истекает через 2 часа"   |
| Дедлайн истёк           | 📧 Email        | При истечении | "❗ Срок отметки посещаемости истёк для занятия [...]" |
| Критический срок        | 📧 Email + Push | После 48ч     | "🔴 Требуется срочная отметка посещаемости"            |

### Уведомления для администраторов

| Событие              | Канал        | Описание                                           |
| -------------------- | ------------ | -------------------------------------------------- |
| Просроченные отметки | 📊 Dashboard | Виджет "Неотмеченные занятия"                      |
| Запрос на разрешение | 🔔 Push      | "Инструктор [X] запрашивает разрешение на отметку" |
| Критический уровень  | 📧 Email     | "5 занятий не отмечено более 72ч"                  |

---

## Техническая реализация

### Новые таблицы БД

#### 1. `attendance_marking_status` — Статус отметки занятий

```sql
CREATE TABLE attendance_marking_status (
  id VARCHAR(191) PRIMARY KEY,
  schedule_event_id VARCHAR(191) NOT NULL UNIQUE,
  status ENUM('pending', 'in_progress', 'on_time', 'late', 'overdue', 'approved') DEFAULT 'pending',
  marked_by VARCHAR(191) COMMENT 'ID инструктора, сделавшего отметку',
  marked_at DATETIME(3) COMMENT 'Когда была сделана отметка',
  deadline DATETIME(3) NOT NULL COMMENT 'Крайний срок отметки',
  late_deadline DATETIME(3) NOT NULL COMMENT 'Крайний срок с опозданием',
  late_reason TEXT COMMENT 'Причина опоздания',
  approved_by VARCHAR(191) COMMENT 'Кто одобрил просроченную отметку',
  approved_at DATETIME(3),
  created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
  updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),

  INDEX idx_status (status),
  INDEX idx_deadline (deadline),
  INDEX idx_marked_by (marked_by),

  FOREIGN KEY (schedule_event_id) REFERENCES schedule_events(id) ON DELETE CASCADE,
  FOREIGN KEY (marked_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
);
```

#### 2. `attendance_marking_requests` — Запросы на разрешение

```sql
CREATE TABLE attendance_marking_requests (
  id VARCHAR(191) PRIMARY KEY,
  schedule_event_id VARCHAR(191) NOT NULL,
  instructor_id VARCHAR(191) NOT NULL,
  reason TEXT NOT NULL COMMENT 'Причина опоздания',
  status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  reviewed_by VARCHAR(191),
  reviewed_at DATETIME(3),
  review_comment TEXT,
  created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),

  INDEX idx_status (status),
  INDEX idx_instructor (instructor_id),

  FOREIGN KEY (schedule_event_id) REFERENCES schedule_events(id) ON DELETE CASCADE,
  FOREIGN KEY (instructor_id) REFERENCES instructors(id) ON DELETE CASCADE,
  FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);
```

#### 3. `attendance_settings` — Настройки системы

```sql
CREATE TABLE attendance_settings (
  id INT PRIMARY KEY AUTO_INCREMENT,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value VARCHAR(255) NOT NULL,
  description TEXT,
  updated_by VARCHAR(191),
  updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
);

-- Начальные значения
INSERT INTO attendance_settings (setting_key, setting_value, description) VALUES
('ATTENDANCE_MARK_DEADLINE_HOURS', '24', 'Часов после занятия для обычной отметки'),
('ATTENDANCE_EDIT_DEADLINE_HOURS', '72', 'Часов после занятия для редактирования'),
('ATTENDANCE_LATE_MARK_ALLOWED', 'true', 'Разрешить опоздавшую отметку'),
('ATTENDANCE_REQUIRE_APPROVAL_AFTER_DEADLINE', 'true', 'Требовать одобрение после дедлайна'),
('ATTENDANCE_REMINDER_HOURS_BEFORE', '2', 'За сколько часов до дедлайна напоминать'),
('ATTENDANCE_NOTIFICATION_ADMIN_THRESHOLD', '48', 'После скольких часов уведомлять админа');
```

---

## API эндпоинты

### Новые эндпоинты

| Метод  | Путь                                      | Описание                                     |
| ------ | ----------------------------------------- | -------------------------------------------- |
| `GET`  | `/api/attendance/marking-status`          | Статусы отметки занятий (с фильтрами)        |
| `GET`  | `/api/attendance/marking-status/:eventId` | Статус конкретного занятия                   |
| `POST` | `/api/attendance/mark`                    | Отметить посещаемость (с проверкой допуска)  |
| `GET`  | `/api/attendance/pending`                 | Неотмеченные занятия инструктора             |
| `GET`  | `/api/attendance/overdue`                 | Просроченные отметки (для админов)           |
| `POST` | `/api/attendance/request-approval`        | Запросить разрешение на просроченную отметку |
| `GET`  | `/api/attendance/approval-requests`       | Список запросов на одобрение                 |
| `PUT`  | `/api/attendance/approval-requests/:id`   | Одобрить/отклонить запрос                    |
| `GET`  | `/api/attendance/settings`                | Настройки системы отметки                    |
| `PUT`  | `/api/attendance/settings`                | Обновить настройки                           |

### Обновлённый `POST /api/attendance/mark`

```typescript
interface MarkAttendanceRequest {
  scheduleEventId: string;
  attendances: {
    studentId: string;
    hoursAttended: number;
    notes?: string;
  }[];
  // Дополнительные поля для опоздания
  lateReason?: string; // Если status = 'late'
  approvalRequestId?: string; // Если разрешение было одобрено
}

interface MarkAttendanceResponse {
  success: boolean;
  status: "on_time" | "late" | "requires_approval";
  message: string;
  markedCount?: number;
  deadline?: string; // Если требуется одобрение — показать дедлайн
  requestId?: string; // ID созданного запроса на одобрение
}
```

### Middleware проверки допуска

```typescript
// server/middleware/attendance-access.ts

export async function checkAttendanceAccess(event: H3Event) {
  const userId = event.context.auth?.userId;
  const role = event.context.auth?.role;
  const scheduleEventId =
    getRouterParam(event, "eventId") ||
    (await readBody(event))?.scheduleEventId;

  if (!scheduleEventId) return { allowed: true };

  const scheduleEvent = await getScheduleEventById(scheduleEventId);
  if (!scheduleEvent) {
    throw createError({ statusCode: 404, message: "Занятие не найдено" });
  }

  const now = new Date();
  const settings = await getAttendanceSettings();

  // 1. Проверка: занятие началось?
  if (now < new Date(scheduleEvent.startTime)) {
    throw createError({
      statusCode: 403,
      message: "Отметка посещаемости доступна только после начала занятия",
    });
  }

  // 2. Проверка: инструктор назначен на занятие?
  if (role === "TEACHER") {
    const instructorId = await getInstructorIdByUserId(userId);
    if (scheduleEvent.instructorId !== instructorId) {
      throw createError({
        statusCode: 403,
        message: "Вы не назначены инструктором на это занятие",
      });
    }
  }

  // 3. Проверка временных окон
  const endTime = new Date(scheduleEvent.endTime);
  const deadline = addHours(endTime, settings.ATTENDANCE_MARK_DEADLINE_HOURS);
  const lateDeadline = addHours(
    endTime,
    settings.ATTENDANCE_EDIT_DEADLINE_HOURS
  );

  let accessStatus: "allowed" | "late" | "requires_approval";

  if (now <= deadline) {
    accessStatus = "allowed";
  } else if (now <= lateDeadline && settings.ATTENDANCE_LATE_MARK_ALLOWED) {
    accessStatus = "late";
  } else if (settings.ATTENDANCE_REQUIRE_APPROVAL_AFTER_DEADLINE) {
    accessStatus = "requires_approval";
  } else {
    accessStatus = "late"; // Если не требуется одобрение — всегда late
  }

  return {
    allowed:
      accessStatus !== "requires_approval" ||
      role === "ADMIN" ||
      role === "MANAGER",
    status: accessStatus,
    deadline,
    lateDeadline,
  };
}
```

---

## UI компоненты

### 1. Виджет "Неотмеченные занятия" (Dashboard)

```vue
<!-- components/attendance/PendingAttendanceWidget.vue -->

<template>
  <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
    <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
      <Icon name="heroicons:clipboard-document-check" class="w-5 h-5" />
      Посещаемость к отметке
      <span
        v-if="pendingCount > 0"
        class="bg-red-500 text-white text-xs px-2 py-1 rounded-full"
      >
        {{ pendingCount }}
      </span>
    </h3>

    <div v-if="loading" class="flex justify-center py-4">
      <Spinner />
    </div>

    <div
      v-else-if="pendingEvents.length === 0"
      class="text-gray-500 text-center py-4"
    >
      ✅ Все занятия отмечены
    </div>

    <ul v-else class="space-y-3">
      <li
        v-for="event in pendingEvents"
        :key="event.id"
        class="flex items-center justify-between p-3 rounded-lg"
        :class="getStatusClass(event.markingStatus)"
      >
        <div>
          <p class="font-medium">{{ event.title }}</p>
          <p class="text-sm text-gray-500">
            {{ formatDate(event.endTime) }} • {{ event.group?.code }}
          </p>
        </div>
        <div class="text-right">
          <StatusBadge :status="event.markingStatus" />
          <p class="text-xs mt-1">
            {{ getTimeRemaining(event.deadline) }}
          </p>
        </div>
      </li>
    </ul>

    <NuxtLink
      v-if="pendingEvents.length > 0"
      to="/attendance/pending"
      class="block text-center mt-4 text-primary-600 hover:underline"
    >
      Показать все →
    </NuxtLink>
  </div>
</template>
```

### 2. Модальное окно "Опоздание с отметкой"

```vue
<!-- components/attendance/LateMarkingModal.vue -->

<template>
  <UiModal v-model="isOpen" title="⚠️ Срок отметки истёк">
    <div class="space-y-4">
      <p class="text-gray-600 dark:text-gray-400">
        Срок отметки посещаемости для этого занятия истёк. Отметка будет
        сохранена с пометкой <strong>"Опоздание"</strong>.
      </p>

      <div class="bg-yellow-50 dark:bg-yellow-900/30 p-4 rounded-lg">
        <p class="text-sm">
          <strong>Занятие:</strong> {{ event.title }}<br />
          <strong>Дата:</strong> {{ formatDate(event.startTime) }}<br />
          <strong>Дедлайн был:</strong> {{ formatDate(deadline) }}
        </p>
      </div>

      <div>
        <label class="block text-sm font-medium mb-1">
          Причина опоздания (опционально)
        </label>
        <textarea
          v-model="lateReason"
          rows="3"
          class="w-full border rounded-lg p-2"
          placeholder="Укажите причину, если необходимо..."
        />
      </div>
    </div>

    <template #footer>
      <div class="flex gap-3 justify-end">
        <UiButton variant="outline" @click="isOpen = false"> Отмена </UiButton>
        <UiButton variant="warning" @click="confirmLateMark">
          Подтвердить отметку
        </UiButton>
      </div>
    </template>
  </UiModal>
</template>
```

### 3. Страница "Запросы на одобрение" (для админов)

```vue
<!-- pages/admin/attendance-requests.vue -->

<template>
  <div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-bold mb-6">Запросы на отметку посещаемости</h1>

    <div class="grid gap-4">
      <div
        v-for="request in requests"
        :key="request.id"
        class="bg-white dark:bg-gray-800 rounded-lg shadow p-6"
      >
        <div class="flex items-start justify-between">
          <div>
            <h3 class="font-semibold">{{ request.event.title }}</h3>
            <p class="text-sm text-gray-500">
              {{ request.instructor.fullName }} •
              {{ formatDate(request.createdAt) }}
            </p>
            <p class="mt-2"><strong>Причина:</strong> {{ request.reason }}</p>
          </div>

          <div class="flex gap-2">
            <UiButton variant="success" size="sm" @click="approve(request.id)">
              ✓ Одобрить
            </UiButton>
            <UiButton variant="danger" size="sm" @click="reject(request.id)">
              ✕ Отклонить
            </UiButton>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
```

---

## План реализации

### Этап 1: База данных и типы ✅ ВЫПОЛНЕНО

- [x] Миграция для `attendance_marking_status`
- [x] Миграция для `attendance_marking_requests`
- [x] Миграция для `attendance_settings`
- [x] Типы TypeScript для новых сущностей (`server/types/attendanceMarking.ts`, `app/types/attendanceMarking.ts`)
- [x] Репозиторий `attendanceMarkingRepository.ts`

### Этап 2: API эндпоинты ✅ ВЫПОЛНЕНО

- [x] Функция проверки допуска в репозитории
- [x] `GET /api/attendance/marking/status` — статусы отметки занятий
- [x] `GET /api/attendance/marking/pending` — неотмеченные занятия
- [x] `GET /api/attendance/marking/overdue` — просроченные отметки
- [x] `GET /api/attendance/marking/check/:eventId` — проверка доступа
- [x] `GET /api/attendance/marking/requests` — запросы на одобрение
- [x] `POST /api/attendance/marking/requests` — создать запрос
- [x] `PUT /api/attendance/marking/requests/:id` — рассмотреть запрос
- [x] `GET /api/attendance/marking/settings` — настройки
- [x] `PUT /api/attendance/marking/settings` — обновить настройки
- [x] `POST /api/attendance` — обновлён с проверками допуска

### Этап 3: Уведомления ⏳ ОЖИДАЕТ

- [ ] Cron-задача для проверки дедлайнов
- [ ] Интеграция с системой уведомлений
- [ ] Email-уведомления для критических случаев

### Этап 4: UI компоненты ✅ ВЫПОЛНЕНО

- [x] `PendingAttendanceWidget.vue` — виджет для дашборда
- [x] `LateMarkingModal.vue` — модальное окно опоздания
- [x] `MarkingStatusBadge.vue` — бейдж статуса
- [x] Страница `/attendance/pending` — список неотмеченных занятий
- [x] Страница `/admin/attendance-requests` — запросы на одобрение
- [x] Composable `useAttendanceMarking.ts`
- [x] Добавлены пункты меню в сайдбар
- [x] Интеграция в существующий журнал групп

### Этап 5: Тестирование ⏳ ОЖИДАЕТ

- [ ] Unit-тесты для middleware
- [ ] E2E тесты сценариев
- [ ] Проверка всех временных зон

---

## Итого: ~7 рабочих дней

---

_Документ создан: 09.01.2026_
