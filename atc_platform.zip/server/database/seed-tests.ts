/**
 * Скрипт для создания тестовых данных системы тестирования
 *
 * Создаёт:
 * - 2 банка вопросов (по разным темам)
 * - 20 вопросов в каждом банке
 * - 2 шаблона тестов (по одному на каждый банк)
 *
 * Запуск: npx tsx server/database/seed-tests.ts
 */

import { getDbPool } from '../utils/db';
import { v4 as uuidv4 } from 'uuid';
import { pathToFileURL } from 'url';
import type { PoolConnection } from 'mysql2/promise';

// ============================================================================
// ТИПЫ
// ============================================================================

interface QuestionData {
    question_text: string;
    options: {
        options: Array<{ id: string; text: string; correct: boolean }>;
    };
    explanation?: string;
    difficulty: 'easy' | 'medium' | 'hard';
    language?: 'ru' | 'en' | 'uz';
    tags: string[];
}

interface BankData {
    name: string;
    code: string;
    description: string;
    category: string;
    questions: QuestionData[];
}

interface TemplateData {
    name: string;
    code: string;
    description: string;
    questions_mode: 'all' | 'random' | 'manual';
    questions_count: number | null;
    time_limit_minutes: number;
    passing_score: number;
    max_attempts: number;
    shuffle_questions: boolean;
    shuffle_options: boolean;
    allowed_languages?: string[] | null;
}

// ============================================================================
// ДАННЫЕ ДЛЯ БАНКОВ ВОПРОСОВ
// ============================================================================

/**
 * Банк 1: Охрана труда и техника безопасности
 */
const safetyQuestions: QuestionData[] = [
    {
        question_text: 'Что такое СИЗ?',
        options: {
            options: [
                { id: 'a', text: 'Средства индивидуальной защиты', correct: true },
                { id: 'b', text: 'Система измерения защиты', correct: false },
                { id: 'c', text: 'Специальная инструкция защиты', correct: false },
                { id: 'd', text: 'Стандарт измерения загрязнения', correct: false },
            ],
        },
        explanation: 'СИЗ — это средства индивидуальной защиты, используемые для защиты работника от вредных и опасных производственных факторов.',
        difficulty: 'easy',
        tags: ['СИЗ', 'основы'],
    },
    {
        question_text: 'Какой документ регламентирует требования охраны труда на рабочем месте?',
        options: {
            options: [
                { id: 'a', text: 'Трудовой кодекс РК', correct: true },
                { id: 'b', text: 'Уголовный кодекс РК', correct: false },
                { id: 'c', text: 'Гражданский кодекс РК', correct: false },
                { id: 'd', text: 'Налоговый кодекс РК', correct: false },
            ],
        },
        explanation: 'Требования охраны труда регламентируются Трудовым кодексом Республики Казахстан.',
        difficulty: 'easy',
        tags: ['законодательство', 'основы'],
    },
    {
        question_text: 'Как часто необходимо проводить инструктаж по охране труда на рабочем месте?',
        options: {
            options: [
                { id: 'a', text: 'Один раз в год', correct: false },
                { id: 'b', text: 'Не реже одного раза в 6 месяцев', correct: true },
                { id: 'c', text: 'Один раз в месяц', correct: false },
                { id: 'd', text: 'Только при приёме на работу', correct: false },
            ],
        },
        explanation: 'Повторный инструктаж проводится не реже одного раза в 6 месяцев.',
        difficulty: 'medium',
        tags: ['инструктаж', 'процедуры'],
    },
    {
        question_text: 'Что относится к средствам коллективной защиты?',
        options: {
            options: [
                { id: 'a', text: 'Защитные очки', correct: false },
                { id: 'b', text: 'Каска', correct: false },
                { id: 'c', text: 'Вентиляционные системы', correct: true },
                { id: 'd', text: 'Респиратор', correct: false },
            ],
        },
        explanation: 'Вентиляционные системы защищают всех работников в помещении, поэтому относятся к средствам коллективной защиты.',
        difficulty: 'medium',
        tags: ['защита', 'СКЗ'],
    },
    {
        question_text: 'Какой знак безопасности имеет круглую форму с красной каймой?',
        options: {
            options: [
                { id: 'a', text: 'Предупреждающий', correct: false },
                { id: 'b', text: 'Запрещающий', correct: true },
                { id: 'c', text: 'Предписывающий', correct: false },
                { id: 'd', text: 'Эвакуационный', correct: false },
            ],
        },
        explanation: 'Запрещающие знаки имеют круглую форму с красной каймой и красной перечёркивающей полосой.',
        difficulty: 'easy',
        tags: ['знаки', 'основы'],
    },
    {
        question_text: 'Что должен сделать работник при обнаружении неисправности оборудования?',
        options: {
            options: [
                { id: 'a', text: 'Продолжить работу', correct: false },
                { id: 'b', text: 'Самостоятельно устранить неисправность', correct: false },
                { id: 'c', text: 'Прекратить работу и сообщить руководителю', correct: true },
                { id: 'd', text: 'Дождаться окончания смены', correct: false },
            ],
        },
        explanation: 'При обнаружении неисправности работник обязан немедленно прекратить работу и сообщить руководителю.',
        difficulty: 'easy',
        tags: ['процедуры', 'неисправности'],
    },
    {
        question_text: 'Какой класс опасности имеют вещества, вызывающие смертельное отравление при малых дозах?',
        options: {
            options: [
                { id: 'a', text: '1 класс — чрезвычайно опасные', correct: true },
                { id: 'b', text: '2 класс — высокоопасные', correct: false },
                { id: 'c', text: '3 класс — умеренно опасные', correct: false },
                { id: 'd', text: '4 класс — малоопасные', correct: false },
            ],
        },
        explanation: 'К 1 классу относятся чрезвычайно опасные вещества, способные вызвать смертельное отравление при малых дозах.',
        difficulty: 'hard',
        tags: ['классификация', 'опасность'],
    },
    {
        question_text: 'Какова минимальная ширина прохода между оборудованием?',
        options: {
            options: [
                { id: 'a', text: '0.5 метра', correct: false },
                { id: 'b', text: '0.7 метра', correct: true },
                { id: 'c', text: '1 метр', correct: false },
                { id: 'd', text: '1.5 метра', correct: false },
            ],
        },
        explanation: 'Минимальная ширина прохода между оборудованием должна составлять не менее 0.7 метра.',
        difficulty: 'medium',
        tags: ['нормативы', 'рабочее место'],
    },
    {
        question_text: 'Что такое несчастный случай на производстве?',
        options: {
            options: [
                { id: 'a', text: 'Любое происшествие на работе', correct: false },
                { id: 'b', text: 'Событие, повлёкшее травму работника при исполнении им трудовых обязанностей', correct: true },
                { id: 'c', text: 'Поломка оборудования', correct: false },
                { id: 'd', text: 'Нарушение трудовой дисциплины', correct: false },
            ],
        },
        explanation: 'Несчастный случай на производстве — это событие, в результате которого работник получил травму при исполнении трудовых обязанностей.',
        difficulty: 'easy',
        tags: ['определения', 'основы'],
    },
    {
        question_text: 'Какой вид инструктажа проводится при изменении технологического процесса?',
        options: {
            options: [
                { id: 'a', text: 'Вводный', correct: false },
                { id: 'b', text: 'Первичный', correct: false },
                { id: 'c', text: 'Внеплановый', correct: true },
                { id: 'd', text: 'Целевой', correct: false },
            ],
        },
        explanation: 'Внеплановый инструктаж проводится при изменении технологического процесса, замене оборудования и других изменениях.',
        difficulty: 'medium',
        tags: ['инструктаж', 'процедуры'],
    },
    {
        question_text: 'Какова допустимая норма переноса тяжестей вручную для мужчин?',
        options: {
            options: [
                { id: 'a', text: 'До 20 кг', correct: false },
                { id: 'b', text: 'До 30 кг', correct: false },
                { id: 'c', text: 'До 50 кг', correct: true },
                { id: 'd', text: 'Без ограничений', correct: false },
            ],
        },
        explanation: 'Для мужчин допустимая норма переноса тяжестей вручную составляет до 50 кг.',
        difficulty: 'medium',
        tags: ['нормативы', 'физические нагрузки'],
    },
    {
        question_text: 'Что такое профессиональное заболевание?',
        options: {
            options: [
                { id: 'a', text: 'Любая болезнь работника', correct: false },
                { id: 'b', text: 'Заболевание, вызванное воздействием вредных производственных факторов', correct: true },
                { id: 'c', text: 'Простуда на работе', correct: false },
                { id: 'd', text: 'Травма на производстве', correct: false },
            ],
        },
        explanation: 'Профессиональное заболевание — это заболевание, вызванное систематическим воздействием вредных производственных факторов.',
        difficulty: 'easy',
        tags: ['определения', 'здоровье'],
    },
    {
        question_text: 'Кто несёт ответственность за безопасность труда на предприятии?',
        options: {
            options: [
                { id: 'a', text: 'Только работники', correct: false },
                { id: 'b', text: 'Только инженер по охране труда', correct: false },
                { id: 'c', text: 'Работодатель', correct: true },
                { id: 'd', text: 'Государственная инспекция', correct: false },
            ],
        },
        explanation: 'Согласно Трудовому кодексу, основную ответственность за безопасность труда несёт работодатель.',
        difficulty: 'easy',
        tags: ['законодательство', 'ответственность'],
    },
    {
        question_text: 'Какой цвет имеют предупреждающие знаки безопасности?',
        options: {
            options: [
                { id: 'a', text: 'Красный', correct: false },
                { id: 'b', text: 'Жёлтый', correct: true },
                { id: 'c', text: 'Зелёный', correct: false },
                { id: 'd', text: 'Синий', correct: false },
            ],
        },
        explanation: 'Предупреждающие знаки имеют жёлтый фон с чёрной каймой и символом.',
        difficulty: 'easy',
        tags: ['знаки', 'цвета'],
    },
    {
        question_text: 'Что включает в себя первая помощь при поражении электрическим током?',
        options: {
            options: [
                { id: 'a', text: 'Немедленно сделать искусственное дыхание', correct: false },
                { id: 'b', text: 'Освободить пострадавшего от действия тока, вызвать скорую помощь', correct: true },
                { id: 'c', text: 'Дать пострадавшему воды', correct: false },
                { id: 'd', text: 'Уложить и накрыть одеялом', correct: false },
            ],
        },
        explanation: 'Первое действие — освободить пострадавшего от действия электрического тока, затем вызвать скорую помощь.',
        difficulty: 'medium',
        tags: ['первая помощь', 'электробезопасность'],
    },
    {
        question_text: 'Какая группа по электробезопасности присваивается неэлектротехническому персоналу?',
        options: {
            options: [
                { id: 'a', text: 'I группа', correct: true },
                { id: 'b', text: 'II группа', correct: false },
                { id: 'c', text: 'III группа', correct: false },
                { id: 'd', text: 'IV группа', correct: false },
            ],
        },
        explanation: 'Неэлектротехническому персоналу присваивается I группа по электробезопасности.',
        difficulty: 'medium',
        tags: ['электробезопасность', 'группы'],
    },
    {
        question_text: 'Что такое вредный производственный фактор?',
        options: {
            options: [
                { id: 'a', text: 'Фактор, который может привести к травме', correct: false },
                { id: 'b', text: 'Фактор, воздействие которого может привести к заболеванию', correct: true },
                { id: 'c', text: 'Любые условия труда', correct: false },
                { id: 'd', text: 'Неудобный график работы', correct: false },
            ],
        },
        explanation: 'Вредный производственный фактор — это фактор, воздействие которого на работника может привести к заболеванию.',
        difficulty: 'medium',
        tags: ['определения', 'факторы'],
    },
    {
        question_text: 'В течение какого времени необходимо расследовать лёгкий несчастный случай?',
        options: {
            options: [
                { id: 'a', text: '3 дня', correct: false },
                { id: 'b', text: '5 дней', correct: false },
                { id: 'c', text: '10 дней', correct: true },
                { id: 'd', text: '15 дней', correct: false },
            ],
        },
        explanation: 'Легкие несчастные случаи расследуются в течение 10 рабочих дней.',
        difficulty: 'hard',
        tags: ['процедуры', 'расследование'],
    },
    {
        question_text: 'Что такое опасный производственный фактор?',
        options: {
            options: [
                { id: 'a', text: 'Фактор, воздействие которого может привести к заболеванию', correct: false },
                { id: 'b', text: 'Фактор, воздействие которого может привести к травме или смерти', correct: true },
                { id: 'c', text: 'Неблагоприятные климатические условия', correct: false },
                { id: 'd', text: 'Работа в ночное время', correct: false },
            ],
        },
        explanation: 'Опасный производственный фактор — это фактор, воздействие которого может привести к травме или смерти работника.',
        difficulty: 'medium',
        tags: ['определения', 'факторы'],
    },
    {
        question_text: 'Какова периодичность проверки знаний по охране труда для руководителей?',
        options: {
            options: [
                { id: 'a', text: 'Ежегодно', correct: false },
                { id: 'b', text: 'Один раз в 3 года', correct: true },
                { id: 'c', text: 'Один раз в 5 лет', correct: false },
                { id: 'd', text: 'Только при приёме на работу', correct: false },
            ],
        },
        explanation: 'Руководители и специалисты проходят проверку знаний по охране труда не реже одного раза в 3 года.',
        difficulty: 'hard',
        tags: ['процедуры', 'проверка знаний'],
    },
];

/**
 * Банк 2: Основы программирования
 */
const programmingQuestions: QuestionData[] = [
    {
        question_text: 'Что такое переменная в программировании?',
        options: {
            options: [
                { id: 'a', text: 'Именованная область памяти для хранения данных', correct: true },
                { id: 'b', text: 'Команда для вывода информации', correct: false },
                { id: 'c', text: 'Тип файла', correct: false },
                { id: 'd', text: 'Название программы', correct: false },
            ],
        },
        explanation: 'Переменная — это именованная область памяти, которая может хранить значения определённого типа.',
        difficulty: 'easy',
        tags: ['основы', 'переменные'],
    },
    {
        question_text: 'Какой оператор используется для присваивания значения в большинстве языков программирования?',
        options: {
            options: [
                { id: 'a', text: '==', correct: false },
                { id: 'b', text: '=', correct: true },
                { id: 'c', text: ':=', correct: false },
                { id: 'd', text: '->', correct: false },
            ],
        },
        explanation: 'В большинстве языков программирования для присваивания используется знак равенства (=).',
        difficulty: 'easy',
        tags: ['основы', 'операторы'],
    },
    {
        question_text: 'Что такое цикл в программировании?',
        options: {
            options: [
                { id: 'a', text: 'Однократное выполнение команды', correct: false },
                { id: 'b', text: 'Многократное повторение блока кода', correct: true },
                { id: 'c', text: 'Остановка программы', correct: false },
                { id: 'd', text: 'Объявление переменной', correct: false },
            ],
        },
        explanation: 'Цикл — это конструкция, позволяющая многократно выполнять блок кода до выполнения определённого условия.',
        difficulty: 'easy',
        tags: ['основы', 'циклы'],
    },
    {
        question_text: 'Какой тип данных используется для хранения целых чисел?',
        options: {
            options: [
                { id: 'a', text: 'String', correct: false },
                { id: 'b', text: 'Float', correct: false },
                { id: 'c', text: 'Integer', correct: true },
                { id: 'd', text: 'Boolean', correct: false },
            ],
        },
        explanation: 'Integer (или int) — это тип данных для хранения целых чисел без дробной части.',
        difficulty: 'easy',
        tags: ['типы данных', 'числа'],
    },
    {
        question_text: 'Что такое функция в программировании?',
        options: {
            options: [
                { id: 'a', text: 'Именованный блок кода, выполняющий определённую задачу', correct: true },
                { id: 'b', text: 'Условный оператор', correct: false },
                { id: 'c', text: 'Тип переменной', correct: false },
                { id: 'd', text: 'Файл программы', correct: false },
            ],
        },
        explanation: 'Функция — это именованный блок кода, который можно вызывать для выполнения определённой задачи.',
        difficulty: 'easy',
        tags: ['основы', 'функции'],
    },
    {
        question_text: 'Какой оператор используется для сравнения на равенство?',
        options: {
            options: [
                { id: 'a', text: '=', correct: false },
                { id: 'b', text: '==', correct: true },
                { id: 'c', text: '!=', correct: false },
                { id: 'd', text: '<>', correct: false },
            ],
        },
        explanation: 'Оператор == используется для сравнения двух значений на равенство.',
        difficulty: 'easy',
        tags: ['операторы', 'сравнение'],
    },
    {
        question_text: 'Что такое массив?',
        options: {
            options: [
                { id: 'a', text: 'Одиночная переменная', correct: false },
                { id: 'b', text: 'Упорядоченная коллекция элементов одного типа', correct: true },
                { id: 'c', text: 'Функция для вывода', correct: false },
                { id: 'd', text: 'Оператор цикла', correct: false },
            ],
        },
        explanation: 'Массив — это упорядоченная коллекция элементов, доступ к которым осуществляется по индексу.',
        difficulty: 'medium',
        tags: ['структуры данных', 'массивы'],
    },
    {
        question_text: 'С какого индекса начинается нумерация элементов массива в большинстве языков?',
        options: {
            options: [
                { id: 'a', text: 'С 1', correct: false },
                { id: 'b', text: 'С 0', correct: true },
                { id: 'c', text: 'С -1', correct: false },
                { id: 'd', text: 'С любого', correct: false },
            ],
        },
        explanation: 'В большинстве языков программирования индексация массивов начинается с 0.',
        difficulty: 'easy',
        tags: ['массивы', 'индексация'],
    },
    {
        question_text: 'Что такое условный оператор if?',
        options: {
            options: [
                { id: 'a', text: 'Оператор для повторения кода', correct: false },
                { id: 'b', text: 'Оператор для выполнения кода при истинном условии', correct: true },
                { id: 'c', text: 'Оператор присваивания', correct: false },
                { id: 'd', text: 'Оператор вывода', correct: false },
            ],
        },
        explanation: 'Оператор if выполняет блок кода только если указанное условие истинно.',
        difficulty: 'easy',
        tags: ['управление', 'условия'],
    },
    {
        question_text: 'Что означает термин "отладка" (debugging)?',
        options: {
            options: [
                { id: 'a', text: 'Написание нового кода', correct: false },
                { id: 'b', text: 'Поиск и исправление ошибок в программе', correct: true },
                { id: 'c', text: 'Компиляция программы', correct: false },
                { id: 'd', text: 'Документирование кода', correct: false },
            ],
        },
        explanation: 'Отладка (debugging) — это процесс поиска и исправления ошибок в программном коде.',
        difficulty: 'easy',
        tags: ['процессы', 'отладка'],
    },
    {
        question_text: 'Какой тип данных используется для хранения логических значений true/false?',
        options: {
            options: [
                { id: 'a', text: 'Integer', correct: false },
                { id: 'b', text: 'String', correct: false },
                { id: 'c', text: 'Boolean', correct: true },
                { id: 'd', text: 'Float', correct: false },
            ],
        },
        explanation: 'Boolean — это тип данных, который может принимать только два значения: true или false.',
        difficulty: 'easy',
        tags: ['типы данных', 'логика'],
    },
    {
        question_text: 'Что такое синтаксическая ошибка?',
        options: {
            options: [
                { id: 'a', text: 'Ошибка в логике программы', correct: false },
                { id: 'b', text: 'Нарушение правил написания кода языка программирования', correct: true },
                { id: 'c', text: 'Ошибка при выполнении программы', correct: false },
                { id: 'd', text: 'Ошибка в документации', correct: false },
            ],
        },
        explanation: 'Синтаксическая ошибка возникает при нарушении правил написания кода конкретного языка программирования.',
        difficulty: 'medium',
        tags: ['ошибки', 'синтаксис'],
    },
    {
        question_text: 'Что такое комментарий в коде?',
        options: {
            options: [
                { id: 'a', text: 'Команда для компьютера', correct: false },
                { id: 'b', text: 'Текст, игнорируемый при выполнении программы', correct: true },
                { id: 'c', text: 'Вывод на экран', correct: false },
                { id: 'd', text: 'Объявление переменной', correct: false },
            ],
        },
        explanation: 'Комментарий — это пояснительный текст в коде, который игнорируется при выполнении программы.',
        difficulty: 'easy',
        tags: ['основы', 'комментарии'],
    },
    {
        question_text: 'Какой оператор используется для логического "И"?',
        options: {
            options: [
                { id: 'a', text: '||', correct: false },
                { id: 'b', text: '&&', correct: true },
                { id: 'c', text: '!', correct: false },
                { id: 'd', text: '^', correct: false },
            ],
        },
        explanation: 'Оператор && (двойной амперсанд) используется для логического "И" (AND).',
        difficulty: 'medium',
        tags: ['операторы', 'логика'],
    },
    {
        question_text: 'Что такое рекурсия?',
        options: {
            options: [
                { id: 'a', text: 'Цикл for', correct: false },
                { id: 'b', text: 'Вызов функцией самой себя', correct: true },
                { id: 'c', text: 'Условный оператор', correct: false },
                { id: 'd', text: 'Объявление массива', correct: false },
            ],
        },
        explanation: 'Рекурсия — это техника программирования, при которой функция вызывает сама себя.',
        difficulty: 'hard',
        tags: ['функции', 'рекурсия'],
    },
    {
        question_text: 'Что такое ООП?',
        options: {
            options: [
                { id: 'a', text: 'Объектно-ориентированное программирование', correct: true },
                { id: 'b', text: 'Операционная обработка программ', correct: false },
                { id: 'c', text: 'Оптимизация обработки процессов', correct: false },
                { id: 'd', text: 'Общие основы программирования', correct: false },
            ],
        },
        explanation: 'ООП — объектно-ориентированное программирование, парадигма, основанная на объектах и классах.',
        difficulty: 'medium',
        tags: ['ООП', 'парадигмы'],
    },
    {
        question_text: 'Что такое класс в ООП?',
        options: {
            options: [
                { id: 'a', text: 'Экземпляр объекта', correct: false },
                { id: 'b', text: 'Шаблон для создания объектов', correct: true },
                { id: 'c', text: 'Переменная', correct: false },
                { id: 'd', text: 'Функция', correct: false },
            ],
        },
        explanation: 'Класс — это шаблон или чертёж, определяющий свойства и методы объектов.',
        difficulty: 'medium',
        tags: ['ООП', 'классы'],
    },
    {
        question_text: 'Какой принцип ООП отвечает за сокрытие внутренней реализации?',
        options: {
            options: [
                { id: 'a', text: 'Наследование', correct: false },
                { id: 'b', text: 'Полиморфизм', correct: false },
                { id: 'c', text: 'Инкапсуляция', correct: true },
                { id: 'd', text: 'Абстракция', correct: false },
            ],
        },
        explanation: 'Инкапсуляция — это принцип ООП, обеспечивающий сокрытие внутренней реализации объекта.',
        difficulty: 'hard',
        tags: ['ООП', 'принципы'],
    },
    {
        question_text: 'Что такое API?',
        options: {
            options: [
                { id: 'a', text: 'Application Programming Interface — интерфейс программирования', correct: true },
                { id: 'b', text: 'Automatic Program Installation', correct: false },
                { id: 'c', text: 'Advanced Programming Instructions', correct: false },
                { id: 'd', text: 'Application Protocol Integration', correct: false },
            ],
        },
        explanation: 'API (Application Programming Interface) — это интерфейс для взаимодействия между программными компонентами.',
        difficulty: 'medium',
        tags: ['интерфейсы', 'API'],
    },
    {
        question_text: 'Что такое алгоритм?',
        options: {
            options: [
                { id: 'a', text: 'Язык программирования', correct: false },
                { id: 'b', text: 'Последовательность шагов для решения задачи', correct: true },
                { id: 'c', text: 'Тип данных', correct: false },
                { id: 'd', text: 'Ошибка в программе', correct: false },
            ],
        },
        explanation: 'Алгоритм — это чёткая последовательность шагов для решения определённой задачи.',
        difficulty: 'easy',
        tags: ['основы', 'алгоритмы'],
    },
];

// ============================================================================
// ДАННЫЕ БАНКОВ
// ============================================================================

const BANKS_DATA: BankData[] = [
    {
        name: 'Охрана труда — Базовый уровень',
        code: 'OT-BASE-2026',
        description: 'Банк вопросов по охране труда и технике безопасности. Включает вопросы по СИЗ, знакам безопасности, инструктажам и процедурам.',
        category: 'Охрана труда',
        questions: safetyQuestions,
    },
    {
        name: 'Основы программирования — Начальный уровень',
        code: 'PROG-BASE-2026',
        description: 'Банк вопросов по основам программирования. Охватывает переменные, типы данных, операторы, функции, ООП.',
        category: 'Информатика',
        questions: programmingQuestions,
    },
];

// ============================================================================
// ДАННЫЕ ШАБЛОНОВ ТЕСТОВ
// ============================================================================

const TEMPLATES_DATA: TemplateData[] = [
    {
        name: 'Тест по охране труда (базовый)',
        code: 'TEST-OT-BASE-2026',
        description: 'Базовый тест для проверки знаний по охране труда. 15 случайных вопросов, 30 минут, проходной балл 70%.',
        questions_mode: 'random',
        questions_count: 15,
        time_limit_minutes: 30,
        passing_score: 70,
        max_attempts: 2,
        shuffle_questions: true,
        shuffle_options: true,
    },
    {
        name: 'Тест по основам программирования',
        code: 'TEST-PROG-BASE-2026',
        description: 'Тест для проверки базовых знаний программирования. 20 вопросов, 45 минут, проходной балл 60%.',
        questions_mode: 'all',
        questions_count: null,
        time_limit_minutes: 45,
        passing_score: 60,
        max_attempts: 3,
        shuffle_questions: true,
        shuffle_options: true,
    },
];

// ============================================================================
// ОСНОВНАЯ ФУНКЦИЯ SEED
// ============================================================================

export async function seedTests() {
    console.log('🧪 Начинаем создание тестовых данных для системы тестирования...\n');

    const pool = getDbPool();
    const connection = await pool.getConnection() as PoolConnection;

    try {
        await connection.beginTransaction();

        // Проверяем, есть ли уже данные
        const [existingBanks] = await connection.query<any[]>(
            'SELECT COUNT(*) as count FROM question_banks'
        );

        if (existingBanks[0].count > 0) {
            console.log('ℹ️  Банки вопросов уже существуют. Прекращаем seed.\n');
            console.log('   Для повторного создания данных сначала очистите таблицы:');
            console.log('   - question_banks');
            console.log('   - questions');
            console.log('   - test_templates\n');
            return;
        }

        const bankIds: Map<string, string> = new Map();

        // ========================================================================
        // СОЗДАНИЕ БАНКОВ И ВОПРОСОВ
        // ========================================================================

        for (const bankData of BANKS_DATA) {
            console.log(`📦 Создаём банк: "${bankData.name}"...`);

            const bankId = uuidv4();
            const now = new Date();

            // Создаём банк
            await connection.execute(
                `INSERT INTO question_banks (id, name, code, description, category, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [bankId, bankData.name, bankData.code, bankData.description, bankData.category, true, now, now]
            );

            bankIds.set(bankData.code, bankId);
            console.log(`   ✓ Банк создан: ${bankData.code} (ID: ${bankId})`);

            // Создаём вопросы
            console.log(`   📝 Добавляем ${bankData.questions.length} вопросов...`);

            for (let i = 0; i < bankData.questions.length; i++) {
                const q = bankData.questions[i];
                const questionId = uuidv4();

                await connection.execute(
                    `INSERT INTO questions (
            id, bank_id, question_type, question_text, options,
            points, explanation, difficulty, language, tags, order_index, is_active,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        questionId,
                        bankId,
                        'single',
                        q.question_text,
                        JSON.stringify(q.options),
                        1,
                        q.explanation || null,
                        q.difficulty,
                        q.language || 'ru',
                        JSON.stringify(q.tags),
                        i + 1,
                        true,
                        now,
                        now,
                    ]
                );
            }

            console.log(`   ✓ Добавлено ${bankData.questions.length} вопросов\n`);
        }

        // ========================================================================
        // СОЗДАНИЕ ШАБЛОНОВ ТЕСТОВ
        // ========================================================================

        console.log('📋 Создаём шаблоны тестов...\n');

        // Шаблон 1 - для банка охраны труда
        const template1 = TEMPLATES_DATA[0];
        const bankCode1 = BANKS_DATA[0].code;
        const bankId1 = bankIds.get(bankCode1)!;
        const templateId1 = uuidv4();
        const now = new Date();

        await connection.execute(
            `INSERT INTO test_templates (
        id, bank_id, name, code, description, questions_mode, questions_count,
        time_limit_minutes, passing_score, max_attempts, shuffle_questions,
        shuffle_options, questions_per_page, show_results, allow_back,
        proctoring_enabled, allowed_languages, is_active, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                templateId1,
                bankId1,
                template1.name,
                template1.code,
                template1.description,
                template1.questions_mode,
                template1.questions_count,
                template1.time_limit_minutes,
                template1.passing_score,
                template1.max_attempts,
                template1.shuffle_questions,
                template1.shuffle_options,
                1, // questions_per_page
                'immediately', // show_results
                true, // allow_back
                false, // proctoring_enabled
                template1.allowed_languages ? JSON.stringify(template1.allowed_languages) : null,
                true, // is_active
                now,
                now,
            ]
        );

        console.log(`   ✓ Шаблон создан: "${template1.name}"`);
        console.log(`     Код: ${template1.code}`);
        console.log(`     Банк: ${bankCode1}`);
        console.log(`     Режим: ${template1.questions_mode} (${template1.questions_count || 'все'} вопросов)`);
        console.log(`     Время: ${template1.time_limit_minutes} мин, Проходной: ${template1.passing_score}%\n`);

        // Шаблон 2 - для банка программирования
        const template2 = TEMPLATES_DATA[1];
        const bankCode2 = BANKS_DATA[1].code;
        const bankId2 = bankIds.get(bankCode2)!;
        const templateId2 = uuidv4();

        await connection.execute(
            `INSERT INTO test_templates (
        id, bank_id, name, code, description, questions_mode, questions_count,
        time_limit_minutes, passing_score, max_attempts, shuffle_questions,
        shuffle_options, questions_per_page, show_results, allow_back,
        proctoring_enabled, allowed_languages, is_active, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                templateId2,
                bankId2,
                template2.name,
                template2.code,
                template2.description,
                template2.questions_mode,
                template2.questions_count,
                template2.time_limit_minutes,
                template2.passing_score,
                template2.max_attempts,
                template2.shuffle_questions,
                template2.shuffle_options,
                1, // questions_per_page
                'immediately', // show_results
                true, // allow_back
                false, // proctoring_enabled
                template2.allowed_languages ? JSON.stringify(template2.allowed_languages) : null,
                true, // is_active
                now,
                now,
            ]
        );

        console.log(`   ✓ Шаблон создан: "${template2.name}"`);
        console.log(`     Код: ${template2.code}`);
        console.log(`     Банк: ${bankCode2}`);
        console.log(`     Режим: ${template2.questions_mode} (${template2.questions_count || 'все'} вопросов)`);
        console.log(`     Время: ${template2.time_limit_minutes} мин, Проходной: ${template2.passing_score}%\n`);

        // Коммитим транзакцию
        await connection.commit();

        // ========================================================================
        // ИТОГОВАЯ СТАТИСТИКА
        // ========================================================================

        console.log('═══════════════════════════════════════════════════════════════');
        console.log('✅ SEED УСПЕШНО ЗАВЕРШЁН');
        console.log('═══════════════════════════════════════════════════════════════');
        console.log('');
        console.log('📊 Созданные данные:');
        console.log('');
        console.log(`   📦 Банков вопросов:     ${BANKS_DATA.length}`);
        console.log(`   📝 Вопросов всего:      ${BANKS_DATA.reduce((sum, b) => sum + b.questions.length, 0)}`);
        console.log(`   📋 Шаблонов тестов:     ${TEMPLATES_DATA.length}`);
        console.log('');
        console.log('📑 Детализация:');
        console.log('');

        for (const bank of BANKS_DATA) {
            console.log(`   • ${bank.name}`);
            console.log(`     Код: ${bank.code}`);
            console.log(`     Категория: ${bank.category}`);
            console.log(`     Вопросов: ${bank.questions.length}`);
            console.log('');
        }

        console.log('═══════════════════════════════════════════════════════════════');
        console.log('');
        console.log('🚀 Теперь вы можете:');
        console.log('   1. Перейти в Банк тестов (/test-bank) и увидеть созданные банки');
        console.log('   2. Посмотреть шаблоны тестов (/test-bank/templates)');
        console.log('   3. Привязать тесты к дисциплинам в разделе Программы');
        console.log('');

    } catch (error) {
        await connection.rollback();
        console.error('\n❌ Ошибка при создании тестовых данных:', error);
        throw error;
    } finally {
        connection.release();
    }
}

// ============================================================================
// CLI EXECUTION
// ============================================================================

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
    seedTests()
        .then(() => {
            console.log('Скрипт завершён успешно.');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Скрипт завершён с ошибкой:', error);
            process.exit(1);
        });
}
