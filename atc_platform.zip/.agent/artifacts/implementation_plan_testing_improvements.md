# План реализации улучшений системы тестирования

## 📋 Обзор задач

Данный документ описывает план реализации следующих улучшений:

1. **Исправить выбор шаблона теста в расписании** - убрать ручной выбор теста при создании занятия типа "assessment", использовать автоматически привязанный к дисциплине
2. **Автоматическое выставление оценок за тест в журнал** - после прохождения теста оценка автоматически записывается в журнал группы за соответствующую дату
3. **Детали ответов студентов в журнале** - добавить просмотр того, как студент отвечал на каждый вопрос теста
4. **Аналитика по шаблону теста** - в разделе шаблонов показать список сдавших и статистику

---

## 🎯 Задача 1: Исправить логику выбора шаблона теста

### Текущее поведение (проблема)
- При создании занятия типа "assessment" в `EventModal.vue` появляется выпадающий список для ручного выбора теста
- Это неправильно, т.к. тесты уже привязаны к дисциплинам в разделе "Учебные программы" (`/programs`)

### Новое поведение
- При выборе типа "assessment" система автоматически проверяет, есть ли привязанный тест к выбранной дисциплине
- Если тест привязан — он автоматически будет использован (без ручного выбора)
- Если тестов несколько — показывать информационное сообщение о количестве привязанных тестов
- Если тест не привязан — показывать предупреждение о необходимости привязать тест в разделе "Учебные программы"

### Файлы для изменения

| Файл | Изменения |
|------|-----------|
| `app/components/schedule/EventModal.vue` | Убрать выпадающий список выбора теста, добавить автоматическое связывание |

### Детальный план

#### Шаг 1.1: Изменить секцию выбора теста в EventModal.vue

**Текущий код (строки 141-216):**
```vue
<div v-if="form.eventType === 'assessment' && form.disciplineId" ...>
  <!-- Выпадающий список выбора теста -->
  <select v-model="selectedTestId">...
```

**Новый код:**
- Убрать выпадающий список (select)
- Показывать информационное сообщение:
  - Если есть 1 тест: "Будет использован тест: [название]"
  - Если нет тестов: "⚠️ К дисциплине не привязан тест. Привяжите тест в разделе Учебные программы"
  - Если несколько тестов: "К дисциплине привязано N тестов. Будут созданы назначения для всех."

#### Шаг 1.2: Изменить логику создания test_assignment

**Текущая логика (createTestAssignment):**
- Создаёт assignment только для выбранного вручную теста

**Новая логика:**
- Если к дисциплине привязаны тесты — автоматически создавать `test_assignment` для всех привязанных тестов
- Если тестов нет — не создавать assignment (занятие без автоматического теста)

#### Шаг 1.3: Обновить API endpoint для создания назначений

**Файл:** `server/api/tests/assignments/index.post.ts`

Добавить возможность:
- Создавать назначения для всех тестов дисциплины по schedule_event_id и discipline_id
- Либо передать `discipline_id` вместо `test_template_id` для автоматического связывания

---

## 🎯 Задача 2: Автоматическое выставление оценок за тест в журнал

### Текущее поведение (проблема)
- После прохождения теста оценка сохраняется только в `test_sessions.grade`
- В таблицу `grades` (журнал) оценка не попадает автоматически
- Преподаватель должен вручную выставлять оценки

### Новое поведение
- После завершения теста (`finishSession`) оценка автоматически записывается в таблицу `grades`
- Если студент ещё не прошёл тест — при клике на ячейку оценки в журнале показывать предупреждение "Тест не пройден"

### Файлы для изменения

| Файл | Изменения |
|------|-----------|
| `server/repositories/testSessionRepository.ts` | Добавить создание записи в `grades` при `finishSession` |
| `server/api/tests/sessions/[id]/finish.post.ts` | Обеспечить передачу `schedule_event_id` для записи оценки |
| `server/repositories/attendanceRepository.ts` | Добавить функцию `createOrUpdateGrade` |
| `app/components/attendance/AttendanceCell.vue` | Добавить проверку на наличие теста и его статус |

### Детальный план

#### Шаг 2.1: Модифицировать finishSession

**Файл:** `server/repositories/testSessionRepository.ts`

Добавить после обновления `test_sessions`:
```typescript
// После finishSession - создаём запись в grades
if (!session.is_preview && session.assignment_id) {
  // Получаем schedule_event_id из assignment
  const assignment = await getTestAssignmentById(session.assignment_id);
  if (assignment?.schedule_event_id) {
    await createGradeFromTestSession({
      studentId: session.student_id,
      scheduleEventId: assignment.schedule_event_id,
      grade: results.grade,
      notes: `Автоматически: тест "${assignment.template_name}" - ${results.score_percent.toFixed(1)}%`,
      gradedBy: null // системное
    });
  }
}
```

#### Шаг 2.2: Создать функцию createGradeFromTestSession

**Файл:** `server/repositories/attendanceRepository.ts`

```typescript
export async function createOrUpdateGrade(input: CreateGradeInput): Promise<Grade> {
  // Проверяем существующую оценку
  const existing = await getGradeByStudentAndEvent(input.studentId, input.scheduleEventId);
  
  if (existing) {
    // Обновляем только если новая оценка выше или это первый ввод
    if (input.grade > existing.grade) {
      return updateGrade(existing.id, { grade: input.grade, notes: input.notes });
    }
    return existing;
  }
  
  // Создаём новую
  return createGrade(input);
}
```

#### Шаг 2.3: Добавить индикатор статуса теста в журнале

**Файл:** `app/components/attendance/AttendanceCell.vue`

При клике на ячейку оценки для занятия типа "assessment":
- Проверить наличие назначенного теста (`test_assignment`)
- Если тест назначен, но студент не прошёл — показать подсказку
- Если тест пройден — показать оценку

---

## 🎯 Задача 3: Детали ответов студентов в журнале

### Описание
В журнале группы для занятий типа "assessment" добавить возможность:
- Просмотреть, как конкретный студент отвечал на вопросы
- Какие ответы были правильными/неправильными
- Время на каждый вопрос

### Новые файлы

| Файл | Назначение |
|------|------------|
| `app/components/attendance/TestResultsModal.vue` | Модальное окно с деталями ответов студента |
| `server/api/tests/sessions/[id]/details.get.ts` | API для получения полных деталей сессии с ответами |

### Детальный план

#### Шаг 3.1: Создать API endpoint для деталей сессии

**Файл:** `server/api/tests/sessions/[id]/details.get.ts`

Возвращает:
```typescript
{
  session: TestSessionWithDetails,
  answers: Array<{
    questionId: string,
    questionText: string,
    questionType: string,
    options: QuestionOption[],
    studentAnswer: AnswerData,
    correctAnswer: string,
    isCorrect: boolean,
    pointsEarned: number,
    timeSpentSeconds: number
  }>,
  template: {
    name: string,
    passingScore: number,
    timeLimit: number
  }
}
```

#### Шаг 3.2: Создать компонент TestResultsModal

**Файл:** `app/components/attendance/TestResultsModal.vue`

Содержит:
- Заголовок с ФИО студента, названием теста, датой
- Общая статистика: баллы, проценты, время, статус
- Список вопросов с ответами студента
- Подсветка правильных/неправильных ответов
- Кнопка закрытия

#### Шаг 3.3: Интегрировать в журнал

**Файл:** `app/pages/groups/journal/[slug].vue`

Добавить:
- Импорт TestResultsModal
- Состояние для открытия модального окна
- При клике на ячейку оценки (assessment) — открыть модальное окно с деталями

---

## 🎯 Задача 4: Аналитика по шаблону теста

### Описание
На странице `/test-bank/templates/[id].vue` добавить:
- Список всех, кто проходил тест на основе этого шаблона
- Статистика: общее количество прохождений, средний балл, процент сдачи

### Изменяемые файлы

| Файл | Изменения |
|------|-----------|
| `app/pages/test-bank/templates/[id].vue` | Добавить секцию с аналитикой и таблицей прохождений |
| `server/api/test-bank/templates/[id]/analytics.get.ts` | Новый API endpoint для аналитики |
| `server/repositories/testSessionRepository.ts` | Добавить функцию получения сессий по template_id |

### Детальный план

#### Шаг 4.1: Создать API endpoint для аналитики

**Файл:** `server/api/test-bank/templates/[id]/analytics.get.ts`

Возвращает:
```typescript
{
  summary: {
    totalSessions: number,           // Всего прохождений
    uniqueStudents: number,          // Уникальных студентов
    averageScore: number,            // Средний балл
    passRate: number,                // Процент сдачи
    averageTimeSeconds: number,      // Среднее время прохождения
    bestScore: number,               // Лучший результат
    worstScore: number               // Худший результат
  },
  byQuestion: Array<{
    questionId: string,
    questionText: string,
    correctRate: number,             // Процент правильных ответов
    averageTimeSeconds: number
  }>,
  sessions: Array<{
    sessionId: string,
    studentId: string,
    studentName: string,
    studentIin: string,
    groupName: string,
    score: number,
    passed: boolean,
    timeSpentSeconds: number,
    completedAt: Date
  }>
}
```

#### Шаг 4.2: Добавить функцию в репозиторий

**Файл:** `server/repositories/testSessionRepository.ts`

```typescript
export async function getTemplateAnalytics(templateId: string): Promise<TemplateAnalytics> {
  // Получаем все сессии по шаблону через test_assignments
  const sessions = await executeQuery<...>(`
    SELECT ts.*, s.full_name, s.pinfl, sg.code as group_code
    FROM test_sessions ts
    JOIN test_assignments ta ON ts.assignment_id = ta.id
    JOIN test_templates tt ON ta.test_template_id = tt.id
    LEFT JOIN students s ON ts.student_id = s.id
    LEFT JOIN study_groups sg ON ta.group_id = sg.id
    WHERE tt.id = ? AND ts.status = 'completed' AND ts.is_preview = false
    ORDER BY ts.completed_at DESC
  `, [templateId]);
  
  // Анализ по вопросам
  const questionStats = await executeQuery<...>(`
    SELECT 
      q.id as question_id,
      q.question_text,
      COUNT(*) as total_answers,
      SUM(CASE WHEN ta.is_correct = 1 THEN 1 ELSE 0 END) as correct_count,
      AVG(ta.time_spent_seconds) as avg_time
    FROM test_answers ta
    JOIN questions q ON ta.question_id = q.id
    JOIN test_sessions ts ON ta.session_id = ts.id
    JOIN test_assignments tass ON ts.assignment_id = tass.id
    WHERE tass.test_template_id = ? AND ts.status = 'completed'
    GROUP BY q.id, q.question_text
  `, [templateId]);
  
  return { summary, byQuestion, sessions };
}
```

#### Шаг 4.3: Обновить страницу шаблона

**Файл:** `app/pages/test-bank/templates/[id].vue`

Добавить новую секцию после существующих карточек:

```vue
<!-- Аналитика прохождений -->
<div class="bg-white dark:bg-boxdark rounded-xl shadow-md p-6 lg:col-span-3">
  <h3 class="text-lg font-semibold mb-4">Аналитика прохождений</h3>
  
  <!-- Статистика -->
  <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
    <div class="text-center">
      <p class="text-2xl font-bold text-primary">{{ analytics.summary.totalSessions }}</p>
      <p class="text-sm text-gray-500">Прохождений</p>
    </div>
    <!-- ... остальные метрики -->
  </div>
  
  <!-- Таблица прохождений -->
  <table class="w-full">
    <thead>
      <tr>
        <th>Студент</th>
        <th>Группа</th>
        <th>Балл</th>
        <th>Статус</th>
        <th>Время</th>
        <th>Дата</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="session in analytics.sessions" :key="session.sessionId">
        <!-- ... данные сессии -->
        <td>
          <button @click="viewSessionDetails(session.sessionId)">
            Подробнее
          </button>
        </td>
      </tr>
    </tbody>
  </table>
  
  <!-- Статистика по вопросам -->
  <h4 class="text-md font-medium mt-6 mb-3">Статистика по вопросам</h4>
  <!-- Таблица/график с процентом правильных ответов -->
</div>
```

---

## 📊 Порядок реализации

### Фаза 1: Базовые изменения (основа)
1. **Задача 2** — Автоматическое выставление оценок в журнал
   - Критически важно для корректной работы системы
   - Зависимость: после этого оценки будут появляться автоматически

### Фаза 2: Интеграция с расписанием
2. **Задача 1** — Исправить логику выбора шаблона теста
   - Зависит от задачи 2 (оценки должны записываться корректно)

### Фаза 3: Улучшение UX
3. **Задача 3** — Детали ответов студентов в журнале
   - Расширяет функционал журнала
   - Не зависит от других задач

### Фаза 4: Аналитика
4. **Задача 4** — Аналитика по шаблону теста
   - Расширяет функционал банка тестов
   - Не зависит от других задач

---

## 📁 Сводка создаваемых/изменяемых файлов

### Новые файлы
| Файл | Назначение |
|------|------------|
| `app/components/attendance/TestResultsModal.vue` | Модальное окно деталей теста |
| `server/api/tests/sessions/[id]/details.get.ts` | API деталей сессии |
| `server/api/test-bank/templates/[id]/analytics.get.ts` | API аналитики шаблона |

### Изменяемые файлы
| Файл | Изменения |
|------|-----------|
| `app/components/schedule/EventModal.vue` | Убрать ручной выбор теста |
| `server/repositories/testSessionRepository.ts` | Добавить запись в grades, аналитику |
| `server/api/tests/sessions/[id]/finish.post.ts` | Интеграция с grades |
| `server/repositories/attendanceRepository.ts` | createOrUpdateGrade |
| `app/components/attendance/AttendanceCell.vue` | Индикатор статуса теста |
| `app/pages/groups/journal/[slug].vue` | Интеграция TestResultsModal |
| `app/pages/test-bank/templates/[id].vue` | Секция аналитики |

---

## ⏱️ Оценка времени

| Задача | Оценка |
|--------|--------|
| Задача 1: Исправить выбор теста | 2-3 часа |
| Задача 2: Автоматическое выставление оценок | 3-4 часа |
| Задача 3: Детали ответов в журнале | 4-5 часов |
| Задача 4: Аналитика по шаблону | 4-5 часов |
| **Итого** | **13-17 часов** |

---

## ✅ Критерии приёмки

### Задача 1 ✅ ВЫПОЛНЕНО
- [x] При создании занятия assessment тест подставляется автоматически из привязки дисциплины
- [x] Нет ручного выбора теста в модальном окне
- [x] Если тест не привязан — показывается предупреждение

### Задача 2 ✅ ВЫПОЛНЕНО (ранее)
- [x] После прохождения теста оценка автоматически появляется в журнале
- [x] Оценка соответствует результату теста (0-100)
- [x] В примечании указан источник оценки

### Задача 3 ✅ ВЫПОЛНЕНО
- [x] В журнале можно кликнуть на оценку за тест и увидеть детали
- [x] Видны все вопросы и ответы студента
- [x] Подсвечены правильные/неправильные ответы

### Задача 4 ✅ ВЫПОЛНЕНО
- [x] На странице шаблона теста видна статистика прохождений
- [x] Есть таблица всех, кто проходил тест
- [x] Есть статистика по вопросам (какие самые сложные)
