# Диагностика системы тестирования

## 🔍 Проблема

Студенты не видят тесты в разделе "Мои тесты" (`/tests/my`).

## 📊 Анализ архитектуры

### Полная цепочка данных:

```
1. question_banks (банки вопросов)
   ↓
2. questions (вопросы)
   ↓
3. test_templates (шаблоны тестов)
   ↓
4. discipline_tests (привязка к дисциплине) ← ВАЖНО!
   ↓
5. schedule_events (занятие типа 'assessment')
   ↓
6. test_assignments (назначение теста) ← СОЗДАЁТСЯ АВТОМАТИЧЕСКИ
   ↓
7. Студент видит тест в /tests/my
```

### Условия видимости теста для студента:

✅ **Обязательные условия:**
1. Тест привязан к дисциплине (`discipline_tests`)
2. Создано занятие типа "assessment" (`schedule_events`)
3. Создано назначение теста (`test_assignments`)
4. Студент входит в группу (`study_group_students`)

## 🔴 Найденные проблемы

### Проблема 1: Невозможность создать несколько тестов на одно занятие

**Статус:** ✅ ИСПРАВЛЕНО

**Было:**
```typescript
// Проверялось: есть ли ЛЮБОЙ тест на занятии
const exists = await testAssignmentExistsForEvent(body.schedule_event_id);
if (exists) {
    return { success: false, message: 'На это занятие уже назначен тест' };
}
```

**Стало:**
```typescript
// Проверяется: назначен ли ЭТОТ КОНКРЕТНЫЙ тест на занятие
const exists = await testAssignmentExistsForEventAndTemplate(
    body.schedule_event_id, 
    body.test_template_id
);
if (exists) {
    return { success: false, message: 'Этот тест уже назначен на данное занятие' };
}
```

**Файлы изменены:**
- `server/repositories/testAssignmentRepository.ts` - добавлена функция `testAssignmentExistsForEventAndTemplate`
- `server/api/tests/assignments/index.post.ts` - использует новую проверку

### Проблема 2: Недостаточное логирование ошибок

**Статус:** ✅ ИСПРАВЛЕНО

Добавлено детальное логирование в:
- `server/api/tests/assignments/index.post.ts` - серверное логирование
- `app/components/schedule/EventModal.vue` - клиентское логирование

## 🧪 Диагностика

### Шаг 1: Проверьте логи браузера

После попытки создать занятие типа "assessment", проверьте консоль браузера:

```
[Schedule] Создание назначения теста: <название теста> { ... }
[Schedule] Ответ сервера: { ... }
```

### Шаг 2: Проверьте логи сервера

В терминале, где запущен `npm run dev`, должны появиться логи:

```
[API tests/assignments] Получен запрос: { ... }
[API tests/assignments] Проверка шаблона теста: ...
[API tests/assignments] Шаблон найден: ...
[API tests/assignments] Создание назначения...
[API tests/assignments] Назначение создано: ...
```

### Шаг 3: Проверьте данные в БД

Выполните SQL-запросы для диагностики:

```sql
-- 1. Проверяем привязку тестов к дисциплинам
SELECT 
    dt.id,
    d.name as discipline_name,
    tt.name as template_name,
    tt.code as template_code,
    dt.is_required
FROM discipline_tests dt
LEFT JOIN disciplines d ON dt.discipline_id = d.id
LEFT JOIN test_templates tt ON dt.test_template_id = tt.id;

-- 2. Проверяем занятия типа assessment
SELECT 
    se.id,
    se.title,
    se.event_type,
    DATE(se.start_time) as event_date,
    sg.code as group_name,
    d.name as discipline_name
FROM schedule_events se
LEFT JOIN study_groups sg ON se.group_id = sg.id
LEFT JOIN disciplines d ON se.discipline_id = d.id
WHERE se.event_type = 'assessment'
ORDER BY se.start_time DESC
LIMIT 20;

-- 3. Проверяем назначения тестов
SELECT 
    ta.id,
    ta.status,
    tt.name as template_name,
    sg.code as group_name,
    DATE(se.start_time) as event_date
FROM test_assignments ta
LEFT JOIN test_templates tt ON ta.test_template_id = tt.id
LEFT JOIN study_groups sg ON ta.group_id = sg.id
LEFT JOIN schedule_events se ON ta.schedule_event_id = se.id
ORDER BY ta.created_at DESC
LIMIT 20;

-- 4. Проверяем, что видит конкретный студент
-- Замените 'STUDENT_ID' на реальный ID студента
SELECT 
    ta.id,
    tt.name as template_name,
    sg.code as group_name,
    ta.status,
    DATE(se.start_time) as event_date
FROM test_assignments ta
JOIN study_groups sg ON ta.group_id = sg.id
JOIN study_group_students sgs ON sg.id = sgs.group_id
JOIN test_templates tt ON ta.test_template_id = tt.id
LEFT JOIN schedule_events se ON ta.schedule_event_id = se.id
WHERE sgs.student_id = 'STUDENT_ID';
```

## 🚀 Следующие шаги

### Вариант A: Текущая логика (через расписание)

Студент видит тесты **только после создания занятия "assessment"**.

**Что нужно сделать:**
1. Убедиться, что тесты привязаны к дисциплинам в `/programs`
2. Создать занятие типа "Проверка знаний" в `/schedule`
3. Система автоматически создаст `test_assignment`
4. Студент увидит тест в `/tests/my`

### Вариант B: Прямая привязка (без расписания)

Студент видит тесты **сразу по дисциплинам**, без создания занятий.

**Требуется реализация:**
- Изменить `getStudentAssignments` для поиска тестов напрямую через `discipline_tests`
- Создавать виртуальные назначения для студентов
- Добавить UI для прохождения тестов без привязки к конкретной дате

## 📝 Инструкция для тестирования

1. **Создайте банк вопросов:**
   - Перейдите в `/test-bank`
   - Создайте банк, например "Основы программирования"
   - Добавьте минимум 5 вопросов

2. **Создайте шаблон теста:**
   - В `/test-bank/templates`
   - Выберите созданный банк
   - Настройте параметры (время, проходной балл)

3. **Привяжите тест к дисциплине:**
   - Перейдите в `/programs`
   - Выберите курс и дисциплину
   - В разделе "Тесты для контроля знаний" добавьте созданный шаблон

4. **Создайте занятие:**
   - Перейдите в `/schedule`
   - Создайте занятие типа "Проверка знаний"
   - Выберите группу и дисциплину (к которой привязан тест)
   - Система автоматически покажет привязанные тесты
   - Сохраните занятие

5. **Проверьте от имени студента:**
   - Войдите как студент из этой группы
   - Перейдите в `/tests/my`
   - Тест должен отображаться

## 🔧 Текущий статус

- ✅ Исправлена проверка дублирования тестов
- ✅ Добавлено детальное логирование
- ⏳ Ожидается тестирование с реальными данными
- ⏳ Проверка логов для выявления точной причины ошибки

## 📞 Если проблема сохраняется

Предоставьте:
1. Логи из консоли браузера (полный вывод `[Schedule]` и `[API tests/assignments]`)
2. Логи из терминала сервера
3. Результаты SQL-запросов из раздела "Диагностика"
