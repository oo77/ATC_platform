# Управление доступностью тестов

## 📋 Логика доступности теста

### Когда тест доступен для студента:

1. ✅ Тест создан и привязан к дисциплине
2. ✅ Создано занятие типа "Проверка знаний"
3. ✅ Создано назначение теста (`test_assignment`)
4. ✅ Студент входит в группу
5. ✅ **Время начала занятия наступило** (`start_date <= NOW`)
6. ✅ Попытки не исчерпаны

### Поля `test_assignments`:

| Поле | Назначение | Значение |
|------|------------|----------|
| `start_date` | Когда тест становится доступен | Время начала занятия |
| `end_date` | До какого времени можно сдавать | NULL (без ограничения) или дата |
| `status` | Статус назначения | scheduled, in_progress, completed, cancelled |

## 🔧 Реализованная логика

### При создании занятия "Проверка знаний":

```javascript
// EventModal.vue
const assignmentData = {
  schedule_event_id: eventId,
  test_template_id: test.test_template_id,
  group_id: form.value.groupId,
  start_date: eventStartTime,  // ← Время начала занятия
};
```

### При проверке доступности на клиенте:

```javascript
// tests/my.vue - canTakeTest()

// 1. Если есть активная сессия - можно продолжить
if (assignment.has_active_session) return true;

// 2. Проверяем статус
if (assignment.status === 'cancelled' || 'completed') return false;

// 3. Проверяем попытки
if (attempts_used >= max_attempts) return false;

// 4. Проверяем время начала
if (start_date && start_date > now) return false;

// 5. Проверяем время окончания
if (end_date && end_date < now) return false;

return true;
```

## ⏰ Обработка часовых поясов

### Проблема:
- БД хранит время как `2026-01-05 09:00:00` (без часового пояса)
- JavaScript `new Date('2026-01-05T09:00:00Z')` интерпретирует как UTC
- Браузер в UTC+5, поэтому 09:00 UTC = 14:00 локально

### Решение:
Парсим дату **без 'Z'**, чтобы интерпретировать как локальное время:

```javascript
const parseLocalDateTime = (dateStr) => {
  // Убираем 'Z' и парсим как локальное время
  const normalized = dateStr.replace('Z', '').replace('T', ' ').trim();
  const parts = normalized.split(/[- :]/);
  
  return new Date(
    parseInt(parts[0]),      // год
    parseInt(parts[1]) - 1,  // месяц (0-indexed)
    parseInt(parts[2]),      // день
    parseInt(parts[3]),      // часы
    parseInt(parts[4]),      // минуты
    parseInt(parts[5])       // секунды
  );
};
```

## 📊 Сценарии

### Сценарий 1: Занятие сегодня в 09:00, сейчас 08:30
- `start_date` = "2026-01-05 09:00:00"
- `now` = 08:30
- `start_date > now` = **true**
- Результат: **❌ Тест недоступен**

### Сценарий 2: Занятие сегодня в 09:00, сейчас 09:30
- `start_date` = "2026-01-05 09:00:00"
- `now` = 09:30
- `start_date > now` = **false**
- Результат: **✅ Тест доступен**

### Сценарий 3: Занятие вчера, `end_date` не установлен
- `start_date` = "2026-01-04 09:00:00"
- `end_date` = NULL
- Результат: **✅ Тест доступен** (нет ограничения по окончанию)

## 🔨 Дополнительные возможности

### Опция 1: Ограничить срок сдачи

В `EventModal.vue` можно добавить UI для выбора `end_date`:

```vue
<input type="datetime-local" v-model="testEndDate" />
```

### Опция 2: Тест доступен сразу

Если нужно сделать тест доступным сразу после создания занятия:

```javascript
const assignmentData = {
  // ...
  start_date: null,  // ← Без ограничения по началу
};
```

### Опция 3: Привязка к расписанию

Использовать `event_date` и `event_time` из `schedule_events` для формирования `start_date`.

## 🐛 Отладка

### Консольные логи:

```
[canTakeTest] Проверка теста "Тест по программированию":
  has_active_session: false
  status: "scheduled"
  attempts_used: 0
  max_attempts: 3
  start_date: "2026-01-05T09:00:00"
  current_time: "2026-01-05T09:30:00"

[canTakeTest] Сравнение: start_date=05.01.2026, 09:00:00, now=05.01.2026, 09:30:00
[canTakeTest] ✅ Тест доступен для прохождения
```

## 📝 Изменённые файлы

1. `app/components/schedule/EventModal.vue`
   - Передаём `eventStartTime` в `createTestAssignments`
   - Устанавливаем `start_date` = время начала занятия

2. `app/pages/tests/my.vue`
   - Функция `parseLocalDateTime` для правильного парсинга дат
   - Обновлённая логика `canTakeTest`

3. `server/repositories/testAssignmentRepository.ts`
   - Функция `testAssignmentExistsForEventAndTemplate`
   - Корректная обработка `start_date` типа `string | Date`
